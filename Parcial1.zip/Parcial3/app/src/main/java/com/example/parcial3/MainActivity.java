package com.example.parcial3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText cuota;
    Spinner cum1;
    Spinner carrera1;
    Spinner institucion1;
    TextView CL;
    TextView DI;
    TextView DC;
    TextView CCAR;
    TextView TLP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DC = findViewById(R.id.descuentoCu);
        TLP = findViewById(R.id.total);
        CCAR = findViewById(R.id.costoCa);
        cum1 = findViewById(R.id.cum);
        DI = findViewById(R.id.descuentoIns);
        CL = findViewById(R.id.costoL);
        cuota = findViewById(R.id.costoc);

        carrera1 = findViewById(R.id.carrera);
        institucion1 = findViewById(R.id.institucion);
    }
    public void Calculo(View view){
        String Select;
        double IngMdBD = 20;
        double IngSis = 25;
        double TecSis = 30;
        double COT;
        String S;
        double pri = 0.10;
        double pub = 0.05;
        String C;
        double IMD = 0.30;
        double IS = 0.40;
        double TS = 0.45;
        double total;
        double dst = 0;
        double DesIn = 0;
        double clbt = 0;


        Select = carrera1.getSelectedItem().toString();
        COT = Double.parseDouble(cuota.getText().toString());
        S = institucion1.getSelectedItem().toString();

        if(Select.equals("Ingenieria en Manejo y Gestión de Base de Datos")){
            clbt = IngMdBD;
            CL.setText("$" + IngMdBD);
        }else{
            if(Select.equals("Ingenieria en Sistemas")){
                clbt = IngSis;
                CL.setText("$" + IngSis);
            }else {
                if(Select.equals("Técnico en Sistemas")){
                    clbt = TecSis;
                    CL.setText("$" + TecSis);
                }
            }
        }
        if(S.equals("Privada")){
            DesIn = (COT*pri);
            DI.setText("$"+(COT*pri));
        }else{
           if(S.equals("Pública")){
               DesIn = (COT*pub);
               DI.setText("$"+(COT*pub));
            }
        }

        String E;
        double Max = 0.25;
        double Medio = 0.20;
        double Minimo = 0.15;
        double Nad = 0;


        E = cum1.getSelectedItem().toString();
        if(E.equals("10")){
            dst = (COT*Max);
            DC.setText("$"+(COT*Max));
        }else{
            if(E.equals("9")){
                dst = (COT*Max);
                DC.setText("$"+(COT*Max));
            }else{
                if(E.equals("8")){
                    dst = (COT*Medio);
                    DC.setText("$"+(COT*Medio));
                }else{
                    if(E.equals("7")){
                        dst = (COT*Minimo);
                        DC.setText("$"+(COT*Minimo));
                    }else{
                        if(E.equals("6")){
                            dst = (COT*Nad);
                            DC.setText("$"+Nad);
                        }
                    }
                }
            }
        }
        double CostC = 0;
        C = carrera1.getSelectedItem().toString();
        if(C.equals("Ingenieria en Manejo y Gestión de Base de Datos")){
            CostC = (COT*IMD);
            CCAR.setText("$"+(COT*IMD));
        }else{
            if(C.equals("Ingenieria en Sistemas")){
                CostC = (COT*IS);
                CCAR.setText("$"+(COT*IS));
            }else{
                if(C.equals("Técnico en Sistemas")){
                    CostC = (COT*TS);
                    CCAR.setText("$"+(COT*TS));
                }
            }
        }
        double tt1 = 0;
        double tt2 = 0;
        double ttp = 0;
        tt1 = (dst+DesIn);
        tt2 = (clbt+CostC);
        ttp = (tt2 - tt1);

        TLP.setText("$"+ (COT+ttp));
    }
}
