package com.example.imageslider;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

public class MainActivity extends AppCompatActivity {

    SliderView slider1;
    int[] images = {R.drawable.is1,
    R.drawable.is2,
    R.drawable.is4,
    R.drawable.is5,
    R.drawable.is6,
    R.drawable.i4};
    Button url1;

    String url2= "https://youtu.be/s1OxOBPWBeU";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        slider1 = findViewById(R.id.sl);
        url1 = findViewById(R.id.url);

        SliderAdapter sliderAdapter = new SliderAdapter(images);

        slider1.setSliderAdapter(sliderAdapter);
        slider1.setIndicatorAnimation(IndicatorAnimationType.WORM);
        slider1.setSliderTransformAnimation(SliderAnimations.DEPTHTRANSFORMATION);
        slider1.startAutoCycle();

        url1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri _link = Uri.parse(url2);
                Intent i = new Intent(Intent.ACTION_VIEW,_link);
                startActivity(i);
            }
        });

    }






}