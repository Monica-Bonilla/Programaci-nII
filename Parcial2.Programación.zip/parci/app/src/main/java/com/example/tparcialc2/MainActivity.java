package com.example.tparcialc2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageView Mfoto;

    Button btn_galeria, btn_whatsapp, btncorreo;

    private Uri selecimageUri;

    private static final int REQUEST_SELECT_IMAGE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Mfoto = findViewById(R.id.IMGmostrar);
        btn_whatsapp = findViewById(R.id.Ewhats);
        btn_galeria = findViewById(R.id.accGaleria);
        btncorreo = findViewById(R.id.Ecorreo);

        btn_whatsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selecimageUri == null) {
                    Toast.makeText(MainActivity.this, "Elija una imagen primero", Toast.LENGTH_SHORT).show();
                } else {
                    enviarimgwhast(selecimageUri);
                }
            }
        });
        btncorreo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selecimageUri == null) {
                    Toast.makeText(MainActivity.this, "Elija una imagen primero", Toast.LENGTH_SHORT).show();
                } else {
                    enviarimgcorreo(selecimageUri);
                }
            }

        });

        btn_galeria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, REQUEST_SELECT_IMAGE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_SELECT_IMAGE && resultCode == RESULT_OK && data != null) {
            selecimageUri = data.getData();
            Mfoto.setImageURI(selecimageUri);
            btn_whatsapp.setEnabled(true);
            btncorreo.setEnabled(true);
        }
    }
        private void enviarimgwhast(Uri selecimageUri) {
        Intent intentWhat = new Intent(Intent.ACTION_SEND);
        intentWhat.setType("image/*");
        intentWhat.putExtra(Intent.EXTRA_STREAM, selecimageUri);
        intentWhat.setPackage("com.whatsapp");
        startActivity(Intent.createChooser(intentWhat, "Compartir imagenes"));

    }

    private void enviarimgcorreo(Uri selecimageUri) {
        Intent intentCorreo = new Intent(Intent.ACTION_SEND);
        intentCorreo.setType("image/*");
        intentCorreo.putExtra(Intent.EXTRA_STREAM, selecimageUri);
        intentCorreo.setPackage("com.google.android.gm");
        startActivity(Intent.createChooser(intentCorreo, "Compartir imagenes"));


    }

}
