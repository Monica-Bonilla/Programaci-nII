package com.example.tabs_yo;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
public class Quien_soy extends Fragment {

    String nom, ape,car, num, passtime;
    TextView ingrenom, ingreape,ingresaid, ingrenum, ingresapass;
    Button nuevo;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View Datos = inflater.inflate(R.layout.activity_quien_soy, container, false);
        ingrenom = Datos.findViewById(R.id.txtnombre);
        ingreape = Datos.findViewById(R.id.txtApellido);
        ingresaid = Datos.findViewById(R.id.txtcarnet);
        ingrenum = Datos.findViewById(R.id.Txttelefono);
        ingresapass = Datos.findViewById(R.id.txtpastime);
        nom = "MÓNICA ALESSANDRA ";
        ingrenom.setText(nom);
        ape = "BONILLA ESCOBAR ";
        ingreape.setText(ape);
        car = "SMTS144822";
        ingresaid.setText(car);
        num = "6937-9759";
        ingrenum.setText(num);
        passtime = "LEER";
        ingresapass.setText(passtime);

        nuevo = Datos.findViewById(R.id.mensajerW);
        nuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                MensajeM();
            }
        });
        return Datos;
    }
    public void MensajeM(){
        String message = "Hola, Cómo estás";
        String Minumero = "+50369379759"; //
        Uri Ver = Uri.parse("https://wa.me/" + Minumero + "/?text=" + message );
        Intent Interfaz = new Intent(Intent.ACTION_VIEW, Ver);
        startActivity(Interfaz);

    }

}