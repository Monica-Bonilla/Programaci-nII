package com.example.conexiondeactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class conexion2 extends AppCompatActivity {

    TextView TN, dcp, mt, sld, rta, is;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conexion2);

        TN = findViewById(R.id.etiquetan);
        dcp = findViewById(R.id.etiquetad);
        btn = findViewById(R.id.buttonr);
        mt = findViewById(R.id.montoni);
        sld = findViewById(R.id.sueldoN);
        rta = findViewById(R.id.descuento);
        is = findViewById(R.id.isr);




        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             regresar();
            }
        });
    }
    public void regresar(){
        finish();

    }

    @Override
    protected void onResume() {
        super.onResume();

        Bundle traerdatos = getIntent().getExtras();
        if (traerdatos!=null){
            String nombre = traerdatos.getString("nombre");
            String servicio = traerdatos.getString("servicio");
            int monto = traerdatos.getInt("monto");

            TN.setText("Nombre: "+nombre );
            dcp.setText("Descripcion: "+servicio );
            mt.setText("Monto: "+monto );

            double isr = 0.10;
            rta.setText("Descuento: "+ "$"+(monto*isr));
            sld.setText("Sueldo Neto: "+  "$"+(monto-(monto*isr)));
            is.setText("ISR "+" 10%");







        }
    }
}