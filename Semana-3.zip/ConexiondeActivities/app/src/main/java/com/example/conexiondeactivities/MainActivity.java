package com.example.conexiondeactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText nmb;
    EditText srv;
    EditText mtd;
    Button cclr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nmb = findViewById(R.id.nombre);
        srv = findViewById(R.id.servicio);
        mtd = findViewById(R.id.monto);
        cclr = findViewById(R.id.calcular);

        cclr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              salude();

            }
        });
    }

    public void  salude() {
        try {
            String nombre2, servicio2;
            int monto2 = 0;


            nombre2 = nmb.getText().toString();

            servicio2 = srv.getText().toString();

            if (mtd.getText().toString().equals("")) {
                Toast.makeText(this, "Porfavor introduzca la informacion ", Toast.LENGTH_SHORT).show();
            } else {
                monto2 = Integer.parseInt(mtd.getText().toString());
                Intent ventana = new Intent(MainActivity.this, conexion2.class);
                ventana.putExtra("nombre", nombre2);
                ventana.putExtra("servicio", servicio2);
                ventana.putExtra("monto", monto2);


                startActivity(ventana);

            }


        } catch (Exception error) {
            Log.e("errorMainActivity", error.getMessage());
        }

    }

}