package com.example.ejercicio2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText bt;
    TextView rs;
    Spinner sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt=findViewById(R.id.BT);
        rs=findViewById(R.id.RSTD);
        sp=findViewById(R.id.SN);
    }

    public void Conversion(View view) {
        double Btc;
        String selec;
        double Dl = 1;
        double Quet= 7.48;
        double Lem = 24.64;
        double Cord = 36.53;
        double Col = 579.91;

        Btc = Double.parseDouble(bt.getText().toString());
        selec = sp.getSelectedItem().toString();

        if(selec.equals("Quetzales")){
            rs.setText(" Q " + (Btc*Quet));
        }else{
            if(selec.equals("Lempiras")){
                rs.setText(" L " + (Btc*Lem));
            }else{
                if(selec.equals("Córdobas")){
                    rs.setText(" C " + (Btc*Cord));
                }else{
                    if(selec.equals("Colones Costarricenses")){
                        rs.setText(" ₡ " + (Btc*Col));
                    }else{
                        if(selec.equals("Dolares")){
                            rs.setText(" $ " + (Btc*Dl));
                        }
                    }
                }
            }
        }
    }
}
