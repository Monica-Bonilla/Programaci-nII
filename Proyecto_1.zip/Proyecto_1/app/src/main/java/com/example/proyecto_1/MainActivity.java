package com.example.proyecto_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //Declarar el objeto
    TextView Tex1;
    TextView Tex2;
    TextView Tex3;
    TextView Tex4;
    ImageView naranja;

    String mensaje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            Tex1 = findViewById(R.id.Texto1);
            Tex4 = findViewById(R.id.Texto4);
            naranja = findViewById(R.id.Texto2);

            Tex1.setText("Ciclo de vida Activity");

        } catch (Exception error) {
            //logs
            Log.e("TAG_ERRORPRINCIPAL", error.getMessage());
        }

    }
    @Override
    protected void onResume(){
        super.onResume();
        mensaje = "[OnResume]";
        Tex1.setText(mensaje);
    }
    @Override
    protected void onStop(){
        super.onStop();
        mensaje = "[OnStop]";
        Tex4.setText(mensaje);
        naranja.setImageResource(R.drawable.img_1);
    }
}